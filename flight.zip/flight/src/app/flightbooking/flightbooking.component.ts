import { Component, OnInit } from '@angular/core';
import flight_data from '../flight_result';
import city_data from '../city';
@Component({
  selector: 'app-flightbooking',
  templateUrl: './flightbooking.component.html',
  styleUrls: ['./flightbooking.component.css']
})
export class FlightbookingComponent  implements OnInit {
  public showModal : boolean = false;
  showSearchResult : boolean=false;
  public city_data: any;
  public flight_search_data: any;
  passengerClass  ;
  toCity ;
  fromCity;
  checked;
  depart;
  p: number = 1;
  constructor() {}
  ngOnInit()  {
    this.flight_search_data = flight_data;
    this.city_data = city_data
    console.log(this.flight_search_data);
    console.log(this.city_data);
    document.getElementById("defaultOpen").click();
  }
  openPage(pageName,elmnt,color) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].style.backgroundColor = "";
    }
    document.getElementById(pageName).style.display = "block";
    // elmnt.currentTarget.className += " active";
  }
  
  // Get the element with id="defaultOpen" and click on it

  // your code here
  searchFlight() {
    console.log(this.passengerClass);
    console.log(this.depart);
    console.log(this.toCity);
    console.log(this.fromCity);
    if(this.passengerClass == undefined || this.toCity == undefined || this.fromCity == undefined || this.depart == undefined){
      alert("Please fill all field for flight booking");
    }
    else{
      this.showSearchResult = true;
    }
  }
  confirmBookingBtn() {
  }

}
